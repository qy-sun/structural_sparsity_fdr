import tensorflow as tf
import numpy as np
from tensorflow.keras.layers import Dense, Dropout
from tensorflow.keras.models import Sequential
from itertools import combinations
from tensorflow.keras.callbacks import EarlyStopping


# Knockoff matrix generation by autoencoder
def knockoff_construct_Utilde(U, r, met, epoch, loss='mean_squared_error', verb=2):
    n = U.shape[0]
    p = int(U.shape[1])  # 确保p是整数
    r = int(r)  # 确保r也是整数

    # 使用autoencoder估计C
    es = EarlyStopping(monitor='val_loss', patience=30, verbose=2)
    autoencoder = Sequential()
    autoencoder.add(Dense(r, activation=met, input_shape=(p,)))
    autoencoder.add(Dense(p, activation=met))
    autoencoder.compile(loss=loss, optimizer=tf.keras.optimizers.Adam())
    autoencoder.fit(U, U, epochs=epoch, batch_size=32, verbose=verb, validation_split=0.1, callbacks=[es])

    C = autoencoder.predict(U)

    # 构建Utilde
    E = U - C
    sigma = np.sqrt(np.sum(E ** 2) / (n * p))
    Utilde = C + sigma * np.random.randn(n, p)
    return Utilde