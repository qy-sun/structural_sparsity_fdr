### Controlling the false discovery rate by a Latent Gaussian Copula Knockoff procedure
### revised from: https://github.com/AlejandroRomanVasquez/LGCK-LCD/tree/main


library(glmnet)
library(latentcor)
library(glasso)
library(knockoff)

LGCK_knock <- function(X, method = "original") {
  ### Step1: Construct Knockoff Features using copula
  # 1. Latent correlation estimation
  types <- rep("con", ncol(X))  # Assume all variables are continuous
  latentcor_hat <- latentcor_estimation(X, types, method)
  
  # 2. Graphical Lasso estimation
  #Sigma_hat <- glasso_function(latentcor_hat)
  Sigma_hat <- latentcor_hat
  
  # 3. Transform data to Gaussian margins
  X_norm_hat <- transform_to_gaussian(X, types)
  
  # 4. Generate Gaussian Knockoffs
  mu <- colMeans(X_norm_hat)  # Mean of normalized X
  Xk_norm_hat <- create.gaussian(X_norm_hat, mu = mu, Sigma = Sigma_hat, method = "equi")
  
  # 5. Inverse transform knockoffs back to original scale
  Xk <- inverse_transform_from_gaussian(X, Xk_norm_hat, types)
  
  # Return results
  list(Xk = Xk)
}

############################################################################
############################################################################
############################################################################
#### Helper function for LGCK

# 1. Helper function for latent correlation estimation
latentcor_estimation <- function(X, types, method) {
  library(latentcor)
  
  # Use latentcor function in R for estimation
  latentcor_result <- latentcor(X, types = types, method = method)
  
  # Return the estimated correlation matrix
  return(latentcor_result$R)
}

# 2. Helper function for Graphical Lasso estimation
glasso_function <- function(latentcor_hat) {
  library(glasso)
  
  # Define the range of lambda values
  lambda1_range <- exp(seq(log(10), log(1e-5), length.out = 30))
  
  best_bic <- Inf
  best_Sigma <- NULL
  
  for (lambda in lambda1_range) {
    glasso_result <- glasso(latentcor_hat, rho = lambda)
    
    # Ensure the resulting covariance matrix is symmetric
    Sigma_hat <- solve(glasso_result$wi)
    Sigma_hat <- (Sigma_hat + t(Sigma_hat)) / 2
    
    bic <- glasso_bic(Sigma_hat, latentcor_hat)
    
    if (bic < best_bic) {
      best_bic <- bic
      best_Sigma <- Sigma_hat
    }
  }
  
  return(best_Sigma)
}

# 2. Helper function to calculate BIC for Graphical Lasso
glasso_bic <- function(Sigma_hat, S) {
  p <- ncol(S)
  n <- nrow(S)
  
  # Ensure the input matrix is symmetric
  Sigma_hat <- (Sigma_hat + t(Sigma_hat)) / 2
  
  log_likelihood <- sum(dmvnorm(S, mu = rep(0, p), sigma = Sigma_hat, log = TRUE))
  num_params <- sum(Sigma_hat != 0)
  bic <- -2 * log_likelihood + num_params * log(n)
  return(bic)
}

# 3. Helper function: Transform data to Gaussian margins
transform_to_gaussian <- function(data_X, column_type, delta_n = 1 / (2 * nrow(data_X))) {
  p <- ncol(data_X)
  X_ecdf <- data_X
  X_norm_hat <- data_X
  
  # Compute ECDF and truncate for continuous variables
  for (i in 1:p) {
    if (column_type[i] == "con") {
      X_ecdf[, i] <- as.vector(ecdf(data_X[, i])(data_X[, i]))
      X_ecdf[, i][X_ecdf[, i] < delta_n] <- delta_n
      X_ecdf[, i][X_ecdf[, i] > (1 - delta_n)] <- 1 - delta_n
      X_norm_hat[, i] <- as.vector(qnorm(X_ecdf[, i]))
    }
  }
  
  return(X_norm_hat)
}


# 5. Helper function: Inverse transform Gaussian knockoffs to original scale
inverse_transform_from_gaussian <- function(data_X, Xk_norm_hat, column_type) {
  p <- ncol(data_X)
  Xk <- data_X  # Initialize Xk with the same structure as data_X
  
  # Transform back to original scale for continuous variables
  for (i in 1:p) {
    if (column_type[i] == "con") {
      Xk[, i] <- as.vector(quantile(data_X[, i], probs = pnorm(Xk_norm_hat[, i]), type = 8))
    }
  }
  
  return(Xk)
}