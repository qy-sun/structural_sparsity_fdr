# This include the Knockoff and Knockoff plus fliter with the known or unknown precision matrix
# to computer the FDR and power
# This master R file includes all the R functions for implementing the knockoff filter and 
# knockoff filter plus in high-dimensional linear regression with known precision matrix
# and estimated precision matrix of by using the innovated scalable efficient 
# estimation (ISEE) procedure introduced in Fan  and Lv (2016).
#
# The ISEE framework has a range of potential applications involving precision 
# (innovated data) matrix including:
#   Linear and nonlinear classifications;
#   Dimension reduction; 
#   Portfolio management;
#   Feature screening and simultaneous inference.
#
# Written by 
# Yingying Fan (fanyingy@marshall.usc.edu) and Jinchi Lv (jinchilv@marshall.usc.edu)
# USC, April 10, 2014
#
# Reference:
# Fan, Y. and Lv, J. (2016). Innovated scalable efficient estimation in ultra-large 
# Gaussian graphical models. The Annals of Statistics, 44, 2098-2126.
#
# List of R functions for graphical knockoff filter procedure:
# Part I: main functions
#   1) gknockoff: main function of graphical knockoff filter with known precision matrix Omega
#   2) gknockoff_unknown: main function of graphical knockoff filter with unknown precision matrix Omega
#      and use ISEE to estimate Omega
#   3) gknockoffX: function generating the knockoff design matrix
#   4) slassotf: function implementing tuning-free sparse regression with scaled Lasso
# Part II: additional functions
#   1) fdr: calculating fdr
#   2) pow: calculating power
# Part III: additional functions plot figure 2 
# Part IV: Scale the columns of a matrix X to have unit norm

###########################################################################
# Part I: main functions
# Part I 1) gknockoff: graphical knockoff filter with the known precision matrix Omega
# Input:
#   X:   n x p design matrix
#   y:   n x 1 response vector
#   q:   nominal FDR level
# Output: 
#   S:   set of discovered variables using graphical knockoff filter
#   S_plus:   set of discovered variables using graphical knockoff plus filter

gknockoff <- function(X, y, q, regfactor = "log"){
  
  # regfactor = "log"  # or "one", "sqrt"
  
  
  n = nrow(X)
  p = ncol(X)
  
  ################################################
  ## Here we use the true Omega to compute FDR and Power
  obj      = ar1.mat(a, p)
  Omega    = obj$Omega
  ###############################################
  # generate the knockoff design matrix with known precision matrix Omega
  Xnew = gknockoffX(X, Omega)
  
  # apply self-tuned scaled Lasso
  obj1 = slassotf(Xnew, y, regfactor, sis.use = 0)
  # beta vector under aligned scale
  betap.stan = obj1$betap.stan
  
  # Calculate knockoff test statistics W_j
  W = c(rep(0, p))
  for (j in 1:p) {
    W[j] = abs(betap.stan[j]) - abs(betap.stan[j+p])
  }
  
  # find the knockoff threshold T
  t = sort(c(0, abs(W)))
  ratio = c(rep(0, p))
  
  for (j in 1:p) {
    ratio[j] = sum(W <= -t[j])/max(1, sum(W >= t[j]))
  }
  id = which(ratio <= q)[1]
  if(length(id) == 0){
    T = Inf
  } else {
    T = t[id]
  }
  
  # set of discovered variables
  S = which(W >= T)
  ############################################################
  # find the knockoff plus threshold T plus
  t_plus = sort(c(0, abs(W)))
  ratio_plus = c(rep(0, p))
  
  for (j in 1:p) {
    ratio_plus[j] = (1+sum(W <= -t_plus[j]))/max(1, sum(W >= t_plus[j]))
  }
  id_plus = which(ratio_plus <= q)[1]
  if(length(id_plus) == 0){
    T_plus = Inf
  } else {
    T_plus = t_plus[id_plus]
  }
  
  # set of discovered variables
  S_plus = which(W >= T_plus)
  
  obj_known = list(W=W, S=S, S_plus = S_plus)
  
}
###########################################################################

###########################################################################
###########################################################################
# Part I: main functions
# Part I 2) gknockoff_unknown: graphical knockoff filter with the unknown precision matrix Omega
# Input:
#   X:   n x p design matrix
#   y:   n x 1 response vector
#   q:   nominal FDR level
# Output: 
#   S:   set of discovered variables using graphical knockoff filter
#   S_plus:   set of discovered variables using graphical knockoff plus filter

gknockoff_unknown <- function(X, y, q, regfactor = "log", npermu = 5, sis.use = 0, bia.cor = 0){
  # initialization of ISEE parameters
  # regfactor = "log"  # or "one", "sqrt"
  # npermu = 1         # or >= 2
  # sis.use = 0        # or 1, whether to use SIS for screening
  # bia.cor = 0        # or 1, whether to apply bias correction for ISEE
  
  n = nrow(X)
  p = ncol(X)
  
  ################################################
  # using ISEE to estimate the Omega
  obj = isee(X, regfactor, npermu, sis.use, bia.cor) 
  if (bia.cor == 1){
  # ISEE with bias correction
    Omega = obj$Omega.isee.c
  } else {
  #  # ISEE with no bias correction
    Omega = obj$Omega.isee
  }
  ################################################
  
  ###############################################
  # generate the knockoff design matrix with the estimated precision matrix Omega 
  Xnew = gknockoffX(X, Omega)
  
  # apply self-tuned scaled Lasso
  obj1 = slassotf(Xnew, y, regfactor, sis.use = 0)
  # beta vector under aligned scale
  betap.stan = obj1$betap.stan
  
  # Calculate knockoff test statistics W_j
  W = c(rep(0, p))
  for (j in 1:p) {
    W[j] = abs(betap.stan[j]) - abs(betap.stan[j+p])
  }
  
  # find the knockoff threshold T
  t = sort(c(0, abs(W)))
  ratio = c(rep(0, p))
  
  for (j in 1:p) {
    ratio[j] = sum(W <= -t[j])/max(1, sum(W >= t[j]))
  }
  id = which(ratio <= q)[1]
  if(length(id) == 0){
    T = Inf
  } else {
    T = t[id]
  }
  
  # set of discovered variables
  S = which(W >= T)
  ############################################################
  # find the knockoff plus threshold T plus
  t_plus = sort(c(0, abs(W)))
  ratio_plus = c(rep(0, p))
  
  for (j in 1:p) {
    ratio_plus[j] = (1+sum(W <= -t_plus[j]))/max(1, sum(W >= t_plus[j]))
  }
  id_plus = which(ratio_plus <= q)[1]
  if(length(id_plus) == 0){
    T_plus = Inf
  } else {
    T_plus = t_plus[id_plus]
  }
  
  # set of discovered variables
  S_plus = which(W >= T_plus)
  
  obj_unknown = list(W=W, S=S, S_plus = S_plus)
  
}
###########################################################################

###########################################################################
# Part I: main functions
# Part I 3) gknockoffX: function generating the knockoff design matrix
#                       with the known precision matrix Omega
# Input:
#   X:      n x p design matrix
#   Omega:  known precision matrix 
# Output: 
#   Xnew:   n x (2p) design matrix = [X X_ko]

gknockoffX <- function(X, Omega){
  n = nrow(X)
  p = ncol(X)
  
  # calculate minimum eigenvalue of Sigma = inv(Omega), i.e. 1/max eigenvalue of Omega
  r = eigen(Omega)  #计算精度矩阵 Omega 的特征值和特征向量
  max.eig = r$values[1]  #取出最大特征值
  
  # diagonal matrix for construction of knockoff variables
  s = (1/max.eig)*diag(p) #构造一个对角矩阵 s，其中每个元素都是精度矩阵的最小特征值的倒数。
  obj = pracma::sqrtm(2*s - s%*%Omega%*%s)
  B = obj$B
  A = diag(p) - s%*%Omega
  # now construct knockoff variables conditional on X
  X_ko = X%*%A + matrix(rnorm(n*p),n,p)%*%B
  Xnew = cbind(X, X_ko)
  
  return(Xnew)
}
###########################################################################




###########################################################################
# Part I: main functions
# Part I 4) slassotf: function implementing tuning-free sparse regression with scaled Lasso
# Windows version; Mac or Linux version
# Lasso implemented with coordinate descent

slassotf <- function(X, y, regfactor = "log", sis.use = 0, maxite = 50, tol = 1e-2){
  # detect the OS
  if (Sys.info()['sysname'] == 'Windows') {
    windows.use = 1
  }else{
    windows.use = 0}
  
  n = nrow(X)
  p = ncol(X)
  
  if (regfactor == "log") {
    reg.fac = log(n)
  }
  if (regfactor == "one") {
    reg.fac = 1
  }
  if (regfactor == "sqrt") {
    reg.fac = sqrt(n)
  }
  
  if (sis.use) {
    set0<-order(abs(cor(y, X)),decreasing=T)
    sis.size = min(floor(n/log(n)),p)
    sis.set= set0[1:sis.size]
  }else {
    sis.set = c(1:p)
  }
  
  # rescale each column of n x p design matrix X to have unit L2-norm
  stan_X = scale(X, center=F, scale=T)/sqrt(n-1)
  y.norm = attr(stan_X,"scale")*sqrt(n-1) 
  X = stan_X
  
  # initialization of lambda
  gata2 <- sqrt(n)/(log(p)*2*p)
  B2 <- qt(1-gata2, n-1)
  lambda <- B2/sqrt(n-1+B2^2)
  
  sigma.old <- 1
  beta.old <- c(rep(0, length(sis.set)))
  last_beta_diff <- 0
  inner <- 0
  while (inner < 5) {
    reg <- sigma.old*lambda*reg.fac
    beta <- slasso(as.matrix(X[, sis.set]), as.vector(y), reg, c(rep(0, length(sis.set))), windows.use, maxite, tol)
    if (reg.fac == 1) {
      beta = beta*(abs(beta) > 1*lambda)
    }else{
      beta = beta*(abs(beta) > 0.5*lambda)
    }
    
    sel.mod = which(beta != 0)
    beta[sel.mod] = slasso(as.matrix(X[, sis.set[sel.mod]]), as.vector(y), reg, c(rep(0, length(sel.mod))), windows.use, maxite, tol)
    beta_diff <- max(abs(beta - beta.old))
    A <- y - X[, sis.set] %*% beta
    sigma <- sqrt(sum(A^2))/sqrt(max(n-sum(beta!=0),0)+1e-20)
    sigma_diff <- abs(sigma - sigma.old)
    
    if (sigma_diff < tol) 
      break
    else if (sigma_diff < tol * 0.1& 
             abs(beta_diff - last_beta_diff) < tol) 
      break
    else {
      sigma.old <- sigma
      beta.old <- beta
      last_beta_diff <- beta_diff
    }
    inner <- inner + 1
  }
  
  # beta vector under aligned scale
  betap.stan = c(rep(0, p))
  betap.stan[sis.set] <- as.vector(beta)
  # beta vector under original scale
  betap = scale(t(betap.stan), center=F, scale=y.norm)
  
  obj=list(betap = betap, betap.stan = betap.stan)
  return(obj)
}
###########################################################################
###########################################################################
# Part II: additional functions
# Part II 1) fdr: calculating fdr

fdr <- function(S, beta.true) {
  fdp = sum(beta.true[S] == 0)/max(1, length(S))
  return(fdp)
}
###########################################################################

###########################################################################
# Part II: additional functions
# Part II 2) pow: calculating power

pow <- function(S, beta.true) {
  tdp = sum(beta.true[S] != 0)/sum(beta.true != 0)
  return(tdp)
}

###########################################################################
# Part III: additional functions plot figure 2   

lasso_max_lambda_glmnet <- function(X, y, nlambda=NULL) {
  n = nrow(X); p = ncol(X)
  if (is.null(nlambda)) nlambda = 5*p
  
  lambda_max = max(abs(t(X) %*% y)) / n
  lambda_min = lambda_max / 2e3
  k = (0:(nlambda-1)) / nlambda
  lambda = lambda_max * (lambda_min/lambda_max)^k
  fit <- glmnet(X, y, intercept=F, standardize=F,
                standardize.response=F, lambda=lambda)
  first_nonzero <- function(x) match(T, abs(x) > 0) # NA if all(x==0)
  indices <- apply(fit$beta, 1, first_nonzero)
  names(indices) <- NULL
  ifelse(is.na(indices), 0, fit$lambda[indices] * n)
}

###################################################################



###################################################################
# Part IV: Scale the columns of a matrix X to have unit norm
normc <- function(X) {
  X.scaled = scale(X, center=FALSE, scale=sqrt(colSums(X^2)))
  X.scaled[,] # No attributes
}

###################################################################

##########################################################
## According to high-Knockoff paper, we first splite the sample into two disjoint group
sample.Splite = function(X, y, ratio){
  n   = nrow(X)
  p   = ncol(X)
  n0  = n*ratio
  n1  = n-n0
  full.sample   = c(1:n)
  scr.sample    = sample(full.sample,n0)
  sel.sample    = setdiff(full.sample,scr.sample)
  X_0           = X[scr.sample,]
  y_0           = y[scr.sample]
  X_1           = X[sel.sample,]
  y_1           = y[sel.sample]
  obj  = list(X0 = X_0, y0 = y_0, X1 = X_1, y1 = y_1)
  return(obj)
}

####################################################################

# 1) run Lasso using regression y on x
lasso_glmnet = function(X, y){
  # apply glmnet package
  # Input:
  #   y:   n x 1 response vector
  #   X:   n x p
  n = nrow(X)
  p = ncol(X)
  glmnet1    = cv.glmnet(X,y)
  betap.stan = coef(glmnet1,s='lambda.min',exact=TRUE)
  S          = which(betap.stan[2:p] != 0)
  return(S)
}

lasso_S = function(X, y, regfactor = "log"){
  # apply self-tuned scaled Lasso
  # Input:
  #   y:   n x 1 response vector
  #   X:   n x p
  
  obj0 = slassotf(X, y, regfactor, sis.use = 0)
  # beta vector under aligned scale
  betap.stan = obj0$betap.stan
  S = which(betap.stan != 0)
  return(S)
}

######################################################

gknockoffX.S <- function(X, Omega_est,S){
  n = nrow(X)
  p = ncol(X)
  
  # calculate minimum eigenvalue of Sigma = inv(Omega), i.e. 1/max eigenvalue of Omega
  r = eigen(Omega_est)
  max.eig = r$values[1]
  
  # diagonal matrix for construction of knockoff variables
  s = (1/max.eig)*diag(p)
  obj3 = pracma::sqrtm(2*s - s%*%Omega_est%*%s)
  B = obj3$B
  A = diag(p) - s%*%Omega_est
  # now construct knockoff variables conditional on X
  X_ko = X%*%A + matrix(rnorm(n*p),n,p)%*%B
  X_ko_S= X_ko[,S]
  X_S   = X[,S] 
  Xnew = cbind(X_S, X_ko_S)
  
  return(Xnew)
}


### apply ISEE to estimate \Omega

Omg = function(X,  regfactor = "log", npermu = 5, sis.use = 0, bia.cor = 0){
  # initialization of ISEE parameters
  # regfactor = "log"  # or "one", "sqrt"
  # npermu = 1         # or >= 2
  # sis.use = 0        # or 1, whether to use SIS for screening
  # bia.cor = 0        # or 1, whether to apply bias correction for ISEE
  
  n = nrow(X)
  p = ncol(X)
  ################################################
  # using ISEE to estimate the Omega
  obj1 = isee(X, regfactor, npermu, sis.use, bia.cor) 
  if (bia.cor == 1){
    # ISEE with bias correction
    Omega_est = obj1$Omega.isee.c
  } else {
    #  # ISEE with no bias correction
    Omega_est = obj1$Omega.isee
  }
  return(Omega_est)
}
####################################################################

gknockoff.split <- function(betap.stan, q){
  
  
  m = length(betap.stan)/2
  
  # Calculate knockoff test statistics W_j
  W = c(rep(0, m))
  for (j in 1:m) {
    W[j] = abs(betap.stan[j]) - abs(betap.stan[j+m])
  }
  
  # find the knockoff threshold T
  t = sort(c(0, abs(W)))
  ratio = c(rep(0, m))
  
  for (j in 1:m) {
    ratio[j] = sum(W <= -t[j])/max(1, sum(W >= t[j]))
  }
  id = which(ratio <= q)[1]
  if(length(id) == 0){
    T = Inf
  } else {
    T = t[id]
  }
  
  # set of discovered variables
  S_hat = which(W >= T)
  ############################################################
  # find the knockoff plus threshold T plus
  t_plus = sort(c(0, abs(W)))
  ratio_plus = c(rep(0, m))
  
  for (j in 1:m) {
    ratio_plus[j] = (1+sum(W <= -t_plus[j]))/max(1, sum(W >= t_plus[j]))
  }
  id_plus = which(ratio_plus <= q)[1]
  if(length(id_plus) == 0){
    T_plus = Inf
  } else {
    T_plus = t_plus[id_plus]
  }
  
  # set of discovered variables
  S_plus = which(W >= T_plus)
  
  obj_unknown = list(W=W, S_hat=S_hat, S_plus = S_plus)
  
}
###########################################################################
