`%||%` <- function(x, y) {
  if (is.null(x)) y else x
}

##################################################
### Knockoff Generation
##################################################
generate_knockoff <- function(X_org,
                              method = c("fixed",
                                         "modelx",
                                         "conditional",
                                         "metropolized",
                                         "mrc",
                                         "mmi",
                                         "ci",
                                         "second_order",
                                         "rank",
                                         "deeplink",
                                         "lgck"),
                              method_args = list()) {
  method <- match.arg(method)
  # 对X_org列向量标准化，但是不中心化
  X_org   <- scale(X_org, center = F, scale = sqrt(colSums(X_org^2)))[,]
  X_tilde <- NULL
  
  if (method == "fixed") {
    #—— Fixed-X Knockoff ——
    # 等距生成
    knock <- create.fixed(X_org, method = method_args$fixed_method %||% "equi")
    X_org   <- knock$X
    X_tilde <- knock$Xk
    
  } else if (method == "modelx") {
    #—— Model-X Knockoff ——
    # 高斯假设
    X_tilde <- create.gaussian(
      X_org,
      mu    = colMeans(X_org),
      Sigma = cov(X_org),
      method = method_args$modelx_method %||% "equi"
    )
    
  } else if (method == "conditional") {
    #—— Relaxing the assumptions of knockoffs by conditioning (Huang & Janson, 2020) ——
    source("Knockoff Generation/cknock_ldg.R")
    X_tilde <- cknockoff.ldg(X_org, method = method_args$cond_method %||% "mix")
    
  } else if (method == "metropolized") {
    #—— Metropolized Knockoff Sampling (Bates et al., 2021) ——
    knockpy <- import("knockpy")
    np      <- import("numpy")
    X_py    <- np$array(X_org)
    Sigma_py<- np$array(cov(X_org))
    lf      <- function(X) sum(X^2)  # 平方和损失
    sampler <- knockpy$metro$MetropolizedKnockoffSampler(
      lf          = lf,                         # 必须提供的损失函数
      X           = X_py,                       # 转换后的设计矩阵
      mu          = np$array(colMeans(X_org)),  # 均值向量
      Sigma       = Sigma_py,                   # 转换后的协方差矩阵
      undir_graph = np$ones(c(as.integer(ncol(X_org)), 
                              as.integer(ncol(X_org))))  # 无向图 (numpy 格式, 确保形状参数为整数)
    )
    X_tilde <- as.matrix(sampler$sample_knockoffs())
    
  } else if (method == "mrc") {
    #—— MRC(MVR): Powerful Knockoffs via Minimizing Reconstructability (Spector and Janson, 2020) ——
    knockpy <- import("knockpy")
    np      <- import("numpy")
    X_py    <- np$array(X_org)
    Sigma_py<- np$array(cov(X_org))
    mu_py   <- np$array(colMeans(X_org))
    S       <- knockpy$mrc$solve_mvr(
      Sigma      = Sigma_py,   # 协方差矩阵
      groups     = NULL,       # 非分组 Knockoff
      tol        = 1e-5,       # 最小特征值容忍度
      verbose    = TRUE,          # 打印优化信息
      num_iter   = 100L,       # 最大迭代次数
      smoothing  = 0,          # 平滑参数
      converge_tol = 1e-3      # 收敛容忍度
    )
    invSigma <- np$linalg$inv(Sigma_py + np$eye(as.integer(ncol(X_org))) * (method_args$regularization %||% 0))
    X_k_py   <- knockpy$knockoffs$produce_MX_gaussian_knockoffs(
      X         = X_py,
      mu        = mu_py,
      invSigma  = invSigma,
      S         = S,
      sample_tol= method_args$sample_tol  %||% 1e-6,
      copies    = 1L           # 每个样本生成一个 Knockoff
    )
    X_tilde <- py_to_r(X_k_py[,,1])
    
  } else if (method == "mmi") {
    #—— MMI: Minimizes the mutual information between X and the knockoffs ——
    knockpy <- import("knockpy")
    np      <- import("numpy")
    X_py    <- np$array(X_org)
    Sigma_py<- np$array(cov(X_org))
    mu_py   <- np$array(colMeans(X_org))
    S       <- knockpy$mrc$solve_maxent(
      Sigma      = Sigma_py,    # 协方差矩阵
      tol        = 1e-5,        # 最小特征值容忍度
      verbose    = TRUE,        # 打印优化信息
      num_iter   = 100L,        # 最大迭代次数
      converge_tol = 1e-3       # 收敛容忍度
    )
    invSigma <- np$linalg$inv(Sigma_py + np$eye(as.integer(ncol(X_org))) * (method_args$regularization %||% 0))
    X_k_py   <- knockpy$knockoffs$produce_MX_gaussian_knockoffs(
      X         = X_py,
      mu        = mu_py,
      invSigma  = invSigma,
      S         = S,
      sample_tol= method_args$sample_tol  %||% 1e-6,
      copies    = 1L            # 每个样本生成一个 Knockoff
    )
    X_tilde <- py_to_r(X_k_py[,,1])
    
  } else if (method == "ci") {
    #—— Power analysis of knockoff filters for correlated designs (Liu and Rigollet, 2019) ——
    knockpy <- import("knockpy")
    np      <- import("numpy")
    X_py    <- np$array(X_org)
    mu_py   <- np$array(colMeans(X_org))
    Sigma_py<- np$array(cov(X_org))
    S <- knockpy$mrc$solve_ciknock(
      Sigma = Sigma_py,         # 协方差矩阵
      tol = 1e-5,               # 最小特征值容忍度
      num_iter = 100L           # 最大迭代次数
    )
    invSigma <- np$linalg$inv(Sigma_py + np$eye(as.integer(ncol(X_org))) * (method_args$regularization %||% 0))
    X_k_py   <- knockpy$knockoffs$produce_MX_gaussian_knockoffs(
      X         = X_py,
      mu        = mu_py,
      invSigma  = invSigma,
      S         = S,
      sample_tol= method_args$sample_tol %||% 1e-6,
      copies    = 1L            # 每个样本生成一个 Knockoff
    )
    X_tilde <- py_to_r(X_k_py[,,1])
    
  } else if (method == "second_order") {
    #—— Second Order Match ——
    X_tilde <- create.second_order(X_org, 
                                   method = method_args$second_order_method %||% "equi")
    
  } else if (method == "rank") {
    #—— RANK ——
    source("Knockoff Generation/RANK/ISEE.R")
    source("Knockoff Generation/RANK/gknockoff_LMs_all.R")
    # using ISEE to estimate the Omega
    obj     <- isee(X_org, "log",
                    npermu = 100,
                    sis.use = 0,
                    bia.cor = method_args$bia.cor %||% 1)
    Omega   <- if ((method_args$bia.cor %||% 1) == 1)
      obj$Omega.isee.c else obj$Omega.isee
    # 一次性生成增广矩阵 X_aug_full (n x 2p)
    X_aug_full <- gknockoffX(X_org, Omega)
    # 拆分回原始和 knockoff
    p0      <- ncol(X_org)
    X_org   <- X_aug_full[, 1:p0, drop = FALSE]
    X_tilde <- X_aug_full[, (p0 + 1):(2 * p0), drop = FALSE]
  } else if (method == "deeplink") {
    #—— DeepLINK ——
    source_python("Knockoff Generation/DeepLINK/deeplink.py")
    source_python("Knockoff Generation/DeepLINK/PCp1_numFactors.py")
    r_hat   <- as.integer(PCp1(X_org, method_args$deeplink_nboot %||% 1000L)[1])
    X_tilde <- knockoff_construct_Utilde(
      X_org,
      r     = r_hat,
      met   = method_args$deeplink_met   %||% "elu",
      epoch = method_args$deeplink_epoch %||% 5000L,
      verb  = FALSE
    )
    
  } else if (method == "lgck") {
    #—— LGCK ——
    source("Knockoff Generation/LGCK_knock.R")
    X_tilde <- LGCK_knock(X_org)$Xk
  }
  
  # 返回 X_org 和 knockoff
  list(X_org   = X_org,
       X_tilde = X_tilde)
}